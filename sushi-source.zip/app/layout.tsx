import './globals.css';
export const metadata = { title:'壽司郎叫號',description:'香港分店叫號、票號追蹤及補檯倒數。非官方工具。',manifest:'/manifest.webmanifest',appleWebApp:{capable:true,title:'壽司郎叫號',statusBarStyle:'default'},icons:{apple:'/icon-192.png'}};
export const viewport = {width:'device-width',initialScale:1,viewportFit:'cover',themeColor:'#b91c2b'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-HK"><body>{children}</body></html>}
