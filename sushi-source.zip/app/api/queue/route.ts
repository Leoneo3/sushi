import {validQueue} from '@/lib/core.mjs';
const base='https://sushipass.sushiro.com.hk';
const headers={'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Cache-Control':'no-store'};
// Only two fixed, public, read-only resources are exposed. No arbitrary upstream URLs.
const cache=new Map<string,{data:unknown,at:number}>();
const pending=new Map<string,Promise<{data:unknown,at:number}>>();
export async function GET(request:Request){
 const u=new URL(request.url),id=u.searchParams.get('id');
 if(id!==null&&!/^[1-9][0-9]{0,3}$/.test(id))return new Response(JSON.stringify({error:'Invalid branch'}),{status:400,headers});
 const key=id??'stores',cached=cache.get(key);
 try{
  if(cached&&Date.now()-cached.at<8000)return Response.json(cached,{headers});
  let job=pending.get(key);
  if(!job){job=(async()=>{
   const path=id?`/api/2.0/remote/groupqueues?region=HK&storeid=${id}`:'/api/2.0/info/storelist?latitude=22&longitude=114&numresults=100&region=HK';
   const r=await fetch(base+path,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(15000),redirect:'manual',cache:'no-store'});
   if(!r.ok)throw Error('Upstream unavailable');const text=await r.text();if(text.length>2000000)throw Error('Response too large');const data=JSON.parse(text);
   if(id?!validQueue(data):(!Array.isArray(data)||!data.length||!data.every(s=>Number.isInteger(s.id)&&s.id>0&&['name','address','area','region'].every(k=>typeof s[k]==='string'))||new Set(data.map(s=>s.id)).size!==data.length))throw Error('Invalid data');
   const result={data,at:Date.now()};if(cache.size>100)cache.clear();cache.set(key,result);return result;
  })();pending.set(key,job);job.finally(()=>pending.delete(key)).catch(()=>{});}
  return Response.json(await job,{headers});
 }catch(error){console.error('Queue fetch failed',error);return Response.json({error:'未能取得叫號資料，請稍後再試。'},{status:502,headers})}
}
