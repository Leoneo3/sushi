import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwind from '@tailwindcss/postcss';
import path from 'node:path';
export default defineConfig({root:'standalone',publicDir:false,base:'./',plugins:[react()],resolve:{alias:{'@':path.resolve('.')}},css:{postcss:{plugins:[tailwind()]}},build:{outDir:'../standalone-dist',emptyOutDir:true,assetsInlineLimit:2000000,cssCodeSplit:false}});
