import fs from 'node:fs';
let html=fs.readFileSync('standalone-dist/index.html','utf8');
html=html.replace(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/g,(_,src)=>'<script type="module">'+fs.readFileSync('standalone-dist/'+src.replace(/^\.\//,''),'utf8').replace(/<\/script/gi,'<\\/script')+'</script>');
html=html.replace(/<link\b[^>]*href="([^"]+\.css)"[^>]*>/g,(_,src)=>'<style>'+fs.readFileSync('standalone-dist/'+src.replace(/^\.\//,''),'utf8')+'</style>');
fs.writeFileSync('public/sushi-queue.html',html);fs.writeFileSync('public/offline.html',html);
console.log('Single HTML:',Buffer.byteLength(html),'bytes');

fs.mkdirSync('docs',{recursive:true});fs.writeFileSync('docs/index.html',html);fs.writeFileSync('docs/.nojekyll','');
for(const name of ['sushi-queue.html','offline.html','manifest.webmanifest','sw.js','icon-192.png','icon-512.png'])fs.copyFileSync('public/'+name,'docs/'+name);
